﻿/// <reference path="d3/d3.js" />
/// <reference path="d3/d3.js" />
var source = '';
var sourcesplit = location.href.split('/');
for (var i = 0; i < sourcesplit.length - 2; i++) {
    source = source + '/' + sourcesplit[i];
}
source = ('//' + source).replace('///', '');
/////Base
///CSS
var appname = "iBots";
var likeDislike =
    '<div class="likedislikediv">' +
    '<a class="like"   id = "{id}" style="color:#0a71af" onclick = "like_(this,\'ham\')" > <i class="fa fa-thumbs-up"></i>' +
    '<b> Like</b>' +
    '</a>' +
    '<a class="dislike" style="color:#af531b"   id = "{id}" onclick="like_(this,\'spam\')"><i class="fa fa-thumbs-down"></i>' +
    '<b> Dislike</b>' +
    '</a>' +
    '</div>';
var loader__ = '<div class="col-md-12" style="margin: 3%;"><div class="lds-grid" style=""><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div><div style="font-size: 51px;color: white;margin-left: 66px;"> Loading</div></div>';
var page_ = location.pathname.split('/')[location.pathname.split('/').length - 1].split('?')[0];
function getext(ext) {
    var cat = 'fa fa-file fa-5x';
    if (ext == 'png' || ext == 'jpg' || ext == 'jpeg') {
        cat = 'fa fa-file-image fa-5x';
    } else if (ext == 'xls' || ext == 'xlsx') {
        cat = 'fa fa-file-excel fa-5x';
    } else if (ext == 'csv') {
        cat = 'fa fa-file-csv fa-5x';
    }
    else if (ext == 'pdf') {
        cat = 'fa fa-file-pdf fa-5x';
    } else if (ext == 'txt') {
        cat = 'fa fa-align-left fa-5x';
    } else if (ext == 'doc' || ext == 'docx') {
        cat = 'fa fa-file-word fa-5x';
    } else if (ext == 'gz' || ext == 'z' || ext == 'rpm' || ext == 'pkg' || ext == 'arj' || ext == '7z' || ext == 'zip' || ext == 'rar') {
        cat = 'fas fa-file-archive fa-5x';
    }
    else if (ext == 'processing') {
        cat = 'fas fa-sync fa-spin fa-5x icon_patch';
    }
    return cat;
}
function hidemyass() {
    setTimeout(
        function () {
            $('#hide-menu a').click();
        }, 2000);
}
function filemanipulator() {
    listmyfiles('Processed', $('#processingfiles'));
    listmyfiles('Ready', $('#readyfiles'));
    listmyfiles('Failed', $('#failedfiles'));
}

//document.write('<link rel="stylesheet" href="' + source + '/assets/font-awesome/css/font-awesome.min.css">');
//document.write('<link href="' + source + '/assets/css/nucleo-icons.css" rel="stylesheet" />');

document.write('<script src="' + source + '/Content/systemJS/d3/d3.js"></script>');
document.write('<script src="' + source + '/Content/systemJS/d3/Render.js"></script>');
///////////////////////////////////////////////////////////////////////////
//Datatable////////////////////////////////////////////////////////////////
document.write('<script src="' + source + '/Content/systemJS/datatable/jquery.dataTables.min.js"></script>');
document.write('<script src="' + source + '/Content/systemJS/datatable/dataTables.colVis.min.js"></script>');
document.write('<script src="' + source + '/Content/systemJS/datatable/dataTables.tableTools.min.js"></script>');
document.write('<script src="' + source + '/Content/systemJS/datatable/dataTables.bootstrap.min.js"></script>');
document.write('<script src="' + source + '/Content/systemJS/datatable/datatables.responsive.min.js"></script>');
document.write('<script src="' + source + '/Content/systemJS/datatable/dataTable.js"></script>');
///////////////////////////////////////////////////////////////////////////
///TAGCLOUD////////////////////////////////////////////////////////////////
document.write('<script src="' + source + '/Content/systemJS/jqcloud/jqcloud-1.0.4.js"></script>');
document.write('<link href="' + source + '/Content/systemJS/jqcloud/jqcloud.css" rel="stylesheet" />');
document.write('<script src="' + source + '/Content/systemJS/jqcloud/cloud_localapi.js"></script>');
///////////////////////////////////////////////////////////////////////////
///ECHART//////////////////////////////////////////////////////////////////
document.write('<script src="' + source + '/Echart/echarts.min.js"></script>');
document.write('<script src="' + source + '/Echart/echarts-gl.min.js"></script>');
document.write('<script src="' + source + '/Echart/ecStat.min.js"></script>');
document.write('<script src="' + source + '/Echart/dataTool.min.js"></script>');
document.write('<script src="' + source + '/Echart/localapi.js"></script>');
///////////////////////////////////////////////////////////////////////////
////Progressbar/////////////////////////////////////////////////////
document.write('<script src="' + source + '/Content/systemJS/progressbar/jquery.progressBarTimer.js"></script>');
document.write('<link href="' + source + '/Content/systemJS/progressbar/jquerysctipttop.css" rel="stylesheet" />');
////////////////////////////////////////////////////////////////////////////
try {
    document.write('<script src="' + source + '/Content/systemJS/pageJS/' + location.pathname.split('/')[location.pathname.split('/').length - 1].split('?')[0] + '.js"></script>');
}
catch (e) { }
document.write('<link href="' + source + '/Content/systemJS/System.css" rel="stylesheet" />');
document.write('<link rel="stylesheet" href="' + source + '/Content/systemJS/all.css"');
//D3///////////////////////////////////////////////////////////////////////
//PageJS///////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//CARD//////////////////////////////////////////////////////////////////////
function createcard(title, content, positionstart, positionend, closeclass) {
    var card_id = $.now() + '_card';
    $('body').append('<div id="' + card_id + '" title="' + title + '">' + content + '</div >');
    $("#" + card_id).dialog({
        dialogClass: closeclass,
        position: { my: positionstart, at: positionend, of: window },
        resizable: false
    });
    $('#' + card_id).parent().find('.ui-dialog-titlebar').append('<span id="' + card_id + '_mini" class="pull-right" style="cursor: pointer;">_</span>');
    $('#' + card_id + '_mini').click(function () {
        $('#' + card_id).slideToggle();
        if ($(this).html() == "_") {
            $(this).html('+');
            $(this).parent().parent()[0].style.opacity = 0.8;
        } else {
            $(this).html('_');
            $(this).parent().parent()[0].style.opacity = 1;
        }
    });
    return card_id;
}
/////////////////////////////////////////////////////////////////////////////
//Blocker////////////////////////////////////////////////////////////////////
function createblobker(close_) {
    var blocker_id = $.now() + '_blocker';
    var closeButt = '<a href="javascript:void(0)" class="closebtn" onclick="unblock_(\'' + blocker_id + '\')">&times;</a>';
    if (close_ == false) {
        closeButt = '';
    }
    $('body').append('<div id="' + blocker_id + '" class="sidenav">' + closeButt + '<div id="blockingData" class="col-md-12"></div></div>');
    return blocker_id;
}
function block_(ele) {
    if (ele != undefined) { $("#"+ele)[0].style.width = "100%"; $('body').attr('style', 'overflow: hidden;');}
}
function unblock_(ele) {
    if (ele != undefined) {$("#"+ele)[0].style.width = "0%"; $('body').attr('style', ''); }
}
//////////////////////////////////////////////////////////////////////////////
/////Scroller
function goto_(ele) {
    $('html, body').animate({ scrollTop: (ele.offset().top - 50) }, 500);
}
function createblob(ele) {
    var blobs = [];
    var fl = $('#' + ele)[0];
    var L = fl.files.length;

    for (var i = 0; i < L; i++) {
        var file = fl.files[i];
        var bytes_per_chunk = 1024 * 1024; //1048576
        var start = 0;
        var end = bytes_per_chunk;
        var size = file.size;
        var j = bytes_per_chunk;
        while (start < size) {
            //push the fragments to an array
            blobs.push(file.slice(start, end));
            start = j;
            j = start + bytes_per_chunk;;
            end = start + bytes_per_chunk;
            if (end > size) {
                end = size;
            }
        }
    }
    blob = blobs.shift();
    return blob;
}
////////////
var mainBlocker = '';
var loadingBlocker = '';

var min_thresold = 70;
var max_thresold = 70;
function getthresold_() {
    $.ajax({
        url: "../appconfig/getresultconfig",
        type: "GET",
        cache: false,
        dataType: 'json',
        async: false,
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            min_thresold = parseInt(data[0]);
            max_thresold = parseInt(data[1]);
        },
        error: function (err) {
        }
    });
}

$(document).ready(function () {
    //mainBlocker = createblobker(true);
    //loadingBlocker = createblobker(false);
    //$('#' + loadingBlocker + ' #blockingData').append(loader__);
    activatesilders();
  

    $('body').tooltip({
        track: true
    });
    ////Title//////////////////////
    $('head').append('<title></title>');
    $('head').append('<meta name="viewport" content="width=device-width, initial-scale=1">');
    $('head').append('<meta http-equiv="X-UA-Compatible" content="IE=edge">');
    $('head').append('<meta charset="utf-8">');
    $('title').html(appname);
    $('.uploader_').click(function () {
        $(this).parent().find('[type="file"]').click();
    });
    $('.uploader_').parent().find('[type="file"]').on('change', function () {
        var fileUpload = $(this).get(0);
        var files = fileUpload.files;
        $(this).parent().find('[type="text"]').val(files[0].name);
        Upload(this);
    });
    $('.files_').click(function () {
        $(this).parent().find('a').click();
    });
    if (location.pathname.split('/')[location.pathname.split('/').length - 1].toLocaleLowerCase().toUpperCase() == 'ANALYTICS') {
        hidemyass();
    }
    if (location.pathname.split('/')[location.pathname.split('/').length - 1].toLocaleLowerCase().toUpperCase() == 'UPLOADDATA') {
        filemanipulator();
        setInterval(function () { filemanipulator();}, 5000);
    }
    
    if (location.pathname.split('/')[location.pathname.split('/').length - 1].split('?')[0].toUpperCase() == 'CONTEXT') {
        $('#search').click(function () {
            if ($('#questions_').val().trim() != '') {
                getanswers_stage1();
            }
        });
        elebleEnter('questions_', 'getanswers_stage1()');
        $('#address_pan').hide();
    } else if (location.pathname.split('/')[location.pathname.split('/').length - 1].split('?')[0].toUpperCase() == 'TICKETCREATION') {
        $('#search').click(function () {
            if ($('#questions_').val().trim() != '') {
                getanswers_stage1(1);
            }
        });
        elebleEnter('questions_', 'getanswers_stage1(1)');
        $('#address_pan').hide();
    }
});


function getanswers_stage1(top) {
    var temp_js = {};
    temp_js.text = $('#questions_').val();
    temp_js.top = 6;
    if (top != undefined) {
        temp_js.top = top;
    }
    var data_ = {};
    data_.callData_questionObj = temp_js;
    $('#answers_').children().each(function () { $(this).remove(); });
   // $('#solutions').children().each(function () { $(this).remove(); });
    $('#searching').show();
    $('#searchable').hide();
    $('#address_pan').slideUp();
    $('#solutions').slideUp();
    $.ajax({
        url: "../Home/getAnswer",
        type: "POST",
        data: JSON.stringify(data_),
        cache: false,
        dataType: 'json',
        async: true,
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            $('#currentquestion').show();
            $('#currentquestion h3').html($('#questions_').val());
            $('#questions_').val('');
            if (location.pathname.split('/')[location.pathname.split('/').length - 1].toUpperCase() == 'CONTEXT') {
                contextpage_fn(data);
            }
            if (location.pathname.split('/')[location.pathname.split('/').length - 1].toUpperCase() == 'TICKETCREATION') {
                ticketCreation_fn(data);
            }
        },
        error: function (err) {
            alert("Error")
        }
    });
}
function ticketCreation_fn(data) {
    var localJSON = JSON.parse(data);
    $('#address_pan').slideDown();
    $('#solutions').slideUp();
    var keys_ = [];
    for (key in localJSON) {
        keys_.push(key);
    }
    var dumbness = true;
    var category_ = [];
    var data_ = [];
    category_.push('all');
    data_.push(100);
    var cnt = 0;
    var class_ = "active";
    $('#solutions_tab').children().each(function () { $(this).remove(); });
    getthresold_();
    for (var i = 0; i < keys_.length; i++) {
        if ((parseFloat(localJSON[keys_[i]].similarity) * 100) >= min_thresold && (parseFloat(localJSON[keys_[i]].similarity) * 100) <= max_thresold) {
            dumbness = false; $('#solutions_tab').append('<li class="' + class_ + '"><a data-toggle="tab" href = "#s' + i.toLocaleString() + '"><span class="">Option ' + (cnt + 1) + '</span></a></li>');
            class_ = '';
            //$('#answers_').append('<div class="alert alert-matt tab" style="margin: 0px;cursor: pointer;border-right:4px solid white" target="source' + i + '"><div class="container"><span>Option ' + (cnt + 1) + '</span></div></div>');
            cnt = cnt + 1;
        }

    }
    class_ = "active";
    $('#solutions_tabContent').children().each(function () { $(this).remove(); });
    getthresold_();
    for (var i = 0; i < keys_.length; i++) {
        if ((parseFloat(localJSON[keys_[i]].similarity) * 100) >= min_thresold && (parseFloat(localJSON[keys_[i]].similarity) * 100) <= max_thresold) {
            var innercontrol = '<div class="row main_" target="' + keys_[i] + '">' +
                '<div class="col-md-8">' +
                '<div class="form-group" style=" margin-bottom: 0px !important;"><h6>Module</h6>' +
                '<input readonly="readonly" type="text" class="form-control" placeholder="" value="' + localJSON[keys_[i]].Module_SubModule.replace('::', ':') + '">' +
                '</div>' +
                '</div>' +
                '<div class="col-md-8">' +
                '<div class="form-group" style=" margin-bottom: 0px !important;"><h6>Priority</h6>' +
                //'<input readonly="readonly" type="text" class="form-control" placeholder="" value="' + localJSON[keys_[i]].Priority + '">' +
                '<select id="ticketpriority" class="form-control"><option value="4 high">High</option><option value="3 normal">Normal</option><option selected value="2 low">Low</option></select>'+
                '</div>' +
                '</div>' +
                '<div class="col-md-8">' +
                '<div class="form-group"><h6>Description</h6>' +
                '<input type="text" class="form-control" id="ticdescription" placeholder="Description">' +
                '</div>' +
                '</div>' +
                '<div class="col-md-6">' +
                '<div class="form-group" >' +
                '<a type="button" style="" class="btn btn-success ticket" onclick="createticket()">Create Ticket</a' +
                '</div>' +
                '</div>' +
                '</div>';
            $('#solutions_tabContent').append('<div class="tab-pane fade ' + class_ + ' in padding-10 no-padding-bottom" id="s' + i + '">' + innercontrol + '</div>');
            
            //$('#answers_').append('<div source' + i + ' class="col-md-12 detailssolution" style="height: 236px;overflow:hidden;border: 1px solid #f7755f;background-color: white;padding: 10px;display:none">' +
            //    innercontrol +
            //    '</div>');
        }
        class_ = '';

    }
    $('#solutions').slideDown();
    //simpleBar('percentGraph', category_, data_);
    $('#searching').hide();
    $('#searchable').show();
    if (dumbness) {
        $('#answers_').append('<div class="col-md-12">I\'m not trained yet to answer this :(</div>');
    } else {
        $('.tab').click(function () {
            $('.detailssolution').each(function () { $(this).hide(); });
            $('.tab').each(function () { $(this).addClass('alert-matt'); });
            $('.tab').each(function () { $(this).removeClass('alert-danger'); });
            $('[' + $(this).attr('target') + ']').show();
            $(this).removeClass('alert-matt');
            $(this).addClass('alert-danger');
        });
        $($('.tab')[0]).click();
    }
}
function contextpage_fn(data) {
    var localJSON = JSON.parse(data);
    $('#address_pan').slideDown();
    var keys_ = [];
    var dumbness = true;
    var category_ = [];
    var data_ = [];
    category_.push('all');
    data_.push(100);
    var needanswer = '';
    $('#answers_pan').slideUp();
    getthresold_();
    for (var i = 0; i < localJSON.length; i++) {
        if ((parseFloat(localJSON[i].similarity) * 100) >= min_thresold && (parseFloat(localJSON[i].similarity) * 100) <= max_thresold && checkEligablility(Number(localJSON[i].cluster_id))) {
            if (needanswer == '') {
                needanswer = localJSON[i].cluster_id;
            }
            dumbness = false;
            category_.push('Answer' + (i + 1));
            data_.push(parseInt(parseFloat(localJSON[i].similarity) * 100));
            var control_ = '<div data-target="' + localJSON[i].cluster_id + '"  onclick="showanswers(' + localJSON[i].cluster_id + ')"class="col-md-2 solseg" style="cursor: pointer;margin: 15px;background-color: #3a36336e;padding: 9px;padding-top: 20px;">' +
                '<p class="alert alert-success" >' + localJSON[i].Module_SubModule.replace('::', ' : ') + '</p>' +
                '<div class="progress progress-striped active">' +
                '<div class="progress-bar bg-color-purple" aria-valuetransitiongoal="25" aria-valuenow="' + parseInt(parseFloat(localJSON[i].similarity) * 100)+'" style="width: ' + parseInt(parseFloat(localJSON[i].similarity) * 100) + '%;">' + parseInt(parseFloat(localJSON[i].similarity) * 100) + '%</div>' +
                '</div>' +
                '</div>' ;
            $('#answers_').append(control_);
        }

    }
    $('#answers_pan').slideDown();
    //simpleBar('percentGraph', category_, data_);
    $('#searching').hide();
    $('#searchable').show();
    if (dumbness) {
        $('#answers_').append('<div class="col-md-12">I\'m not trained yet to answer this :(</div>');
    } else {
        if (needanswer != '') { showanswers(needanswer ); }
    }
}
function elebleEnter(ele, target_fn) {
    $('#' + ele).keypress(function (e) {
        if (e.key == "Enter") {
            $('#' + ele).blur();
            if ($('#' + ele).val() != '') {
                eval(target_fn);
            }
        }
    });
}
function showanswers(key_) {
    $('#solutions').slideUp();
    $('#solutions_tab').children().each(function () { $(this).remove(); });
    $('#solutions_tabContent').children().each(function () { $(this).remove(); });
    $.ajax({
        url: "getAnswersStage2?key=" + key_,
        type: "GET",
        cache: false,
        dataType: 'json',
        async: true,
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            $('#solutions').slideDown();
            $('#answers_ .solseg').each(function () { $(this).attr('style', 'cursor: pointer;margin: 15px;background-color: #3a36336e;padding: 9px;padding-top: 20px;'); });
            $('[data-target="' + key_ + '"]').attr('style', 'cursor: pointer;margin: 15px;background-color: #3a35329e;padding: 9px;padding-top: 20px;');
            var class_ = "active";
            for (var i = 0; i < data.length; i++) {
                $('#solutions_tab').append('<li class="' + class_ + '"><a data-toggle="tab" href = "#s' + i.toLocaleString() + '"><span class="">Solution ' + data[i]._id + '</span></a></li>');
                class_ = '';
            }
            class_ = "active";
            for (var i = 0; i < data.length; i++) {
                $('#solutions_tabContent').append('<div class="tab-pane fade ' + class_+ ' in padding-10 no-padding-bottom" id="s' + i + '">' + data[i].Solution + '</div>');
                class_ = '';
            }
            //$('.tab').click(function () {
            //    $('.detailssolution').each(function () { $(this).hide(); });
            //    $('.tab').each(function () { $(this).addClass('alert-matt'); });
            //    $('.tab').each(function () { $(this).removeClass('alert-danger'); });
            //    $('[' + $(this).attr('target') + ']').show();
            //    $(this).removeClass('alert-matt');
            //    $(this).addClass('alert-danger');
            //});
            //$($('.tab')[0]).click();
        },
        error: function (err) {
            alert("Error")
        }
    });
}
function createticket(description) {
    if (description == undefined) {
        description = $('#ticdescription').val();
    }
    var temp_ = {};
    temp_.issue = $('#currentquestion h3').html();
    temp_.description = description;
    temp_.priority = $('#ticketpriority').val();
    var data_ = {};
    data_.ticketinfo = temp_;
    $.ajax({
        url: "../Home/createticket",
        type: "POST",
        data: JSON.stringify(data_),
        cache: false,
        dataType: 'json',
        async: true,
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            $('.ticket').html(JSON.parse(data).Message);
            $('.ticket').addClass('disabled');
        },
        error: function (err) {
            alert("Error")
        }
    });

}
var list_of_links = '';

function listmyfiles(foldername, ele) {
    $.ajax({
        url: '../Home/get_files?f=' + foldername,
        type: "GET",
        cache: false,
        dataType: 'json',
        async: true,
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            $(ele).children().each(function () { $(this).remove(); });
            for (var i = 0; i < result.length; i++) {
                var cat = 'fa-file';
                var ext = result[i].split('.')[result[i].split('.').length - 1];
                cat = getext(ext);
                $(ele).append('<div class="col-md-1">' +
                    '<div class="well text-center connect">' +
                    '<i class= "' + cat + ' files_" ></i>' +
                    '<br>' +
                    '<span class="font-xs"><b>File ' + (i + 1) + '</b><br></span>' +
                    '<a class="btn btn-xs btn-success margin-top-5 margin-bottom-5" href="' + result[i] + '" download><span class="font-xs">Download</span></a>' +
                    '</div></div>'
                );
            }
        },
        error: function (err) {
            alert(err.statusText);
        }
    });
}

function processfile(filename, target) {
    $.ajax({
        url: "../Home/readandinsert?f=" + filename,
        type: "GET",
        cache: false,
        dataType: 'json',
        async: true,
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            filemanipulator();
            
        },
        error: function (err) {
            alert(err.statusText);
        }
    });
}
function like_(ele, type) {
    var data_ = {};
    data_._id = $(ele)[0].id;
    data_.type = type;
    data_.Solution = $($(ele).parent().parent().parent().find('td')[1]).html();
    data_.target = 'spamham,6611_dump';
    data_.targetcolumn = 'solution';
    $.ajax({
        url: '../Home/changeStatus',
        type: "POST",
        data: JSON.stringify(data_),
        cache: false,
        dataType: 'json',
        async: true,
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (data == 'spam' || data == 'ham') {
                var parent_ = $(ele).parent().parent().parent();
                $(ele).parent().parent().remove();
                getspamham(parent_, $(ele)[0].id);
            }
        },
        error: function (err) {
            alert(err.statusText);
        }
    });
}
function checkEligablility(clusterID) {
    var ret = 0;
    $.ajax({
        url: '../Home/cluster_eligiblity?key=' + clusterID,
        type: "GET",
        cache: false,
        dataType: 'json',
        async: false,
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            ret = parseInt(result);
        },
        error: function (err) {
            alert(err.statusText);
        }
    });
    try {
        if (ret > 0) {
            return true;
        } else {
            return false;
        }
    } catch (e) {
        return false;
    }
}
function cleandata() {
    $.ajax({
        url: '../Home/cleandata',
        type: "GET",
        cache: false,
        dataType: 'json',
        async: true,
        contentType: "application/json; charset=utf-8",
    });
    getcleantrainstatus();
}
function traindata() {
    $.ajax({
        url: '../Home/traindata',
        type: "GET",
        cache: false,
        dataType: 'json',
        async: true,
        contentType: "application/json; charset=utf-8",
    });
    getcleantrainstatus();
}
function getcleantrainstatus() {
    $.ajax({
        url: '../Home/getcleanandtraindata',
        type: "GET",
        cache: false,
        dataType: 'json',
        async: true,
        contentType: "application/json; charset=utf-8",
        success: function (result) {

            if (result[0].status == 'ready') {
                $('.cleandata').html('<i class="fas fa-snowplow"></i> Clean Data');
                $('.cleandata').attr('style', '');  
            }
            else {
                $('.cleandata').html('<i class="fa fa-refresh fa-spin"></i> Cleaning.. ' + result[0].per + '%');
                $('.cleandata').attr('style', 'pointer-events: none;');
            }

            if (result[1].status == 'ready') {
                $('.traindata').html('<i class="fas fa-brain"></i> Train Data');
                $('.traindata').attr('style', 'margin-left:10px');
            }
            else {
                $('.traindata').html('<i class="fa fa-refresh fa-spin"></i> Training.. ' + result[1].per + '%');
                $('.traindata').attr('style', 'margin-left:10px;pointer-events: none;');
            }
        },
        error: function (err) {
            alert(err.statusText);
        }
    });
}
function Upload(uploaderele, slave) {
    if (window.FormData !== undefined) {
        var fileUpload = $(uploaderele).get(0);
        var files = fileUpload.files;
        var fileData = new FormData();
        for (var i = 0; i < files.length; i++) {
            fileData.append("Ready", files[0]);
        }
        var target = $(uploaderele);
        $('#uploadprgress').parent().parent().show();
        $(uploaderele).parent().find('.fa-refresh').show();
        $(uploaderele).parent().find('.fa-upload').hide();
        $(uploaderele).parent().find('input[type="file"]').attr('disabled', 'disabled');
        $.ajax({
            url: '../Home/upload',
            type: "POST",
            contentType: false, // Not to set any content header  
            processData: false, // Not to process data  
            data: fileData,
            async: true,
            
            xhr: function () {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function (evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = (evt.loaded / evt.total) * 100;
                        $('#uploadprgress').html(parseInt(percentComplete) + '%');
                        $('#uploadprgress').attr('style', 'width:' + percentComplete + '%');
                    }
                }, false);
                return xhr;
            },
            success: function (result) {
                $('#uploadprgress').parent().parent().hide();
                $('#uploadprgress').html('0%');
                $('#uploadprgress').attr('style', 'width:0%');
                target.parent().find('.fa-refresh').hide();
                target.parent().find('[type="text"]').val('');
                target.parent().find('.fa-upload').show();
                $(uploaderele).parent().find('input[type="file"]').removeAttr('disabled');
                $(uploaderele).val('');
                filemanipulator();
                //processfile(result[0], target)
            },
            error: function (err) {
                alert(err.statusText);
            }
        });
    } else {
        alert("FormData is not supported.");
    }
}
//var data_ = {};
//var mail_ = {};
//mail_.to = ["abc", "xyz"];
//mail_.form = "123";
//mail_.subject = "test";
//mail_.body = "test_body"
//data_.details = mail_;

function sendmail(data_) {
    $.ajax({
        url: '../outlook/sendmail',
        type: "POST",
        cache: false,
        data: JSON.stringify(data_),
        dataType: 'json',
        async: true,
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            basicalert('Mail', 'Sent to User', 4000);
        },
        error: function (err) {
            alert(err.statusText);
        }
    });
}

function basicalert(title_,content_,timeout) {
    $.smallBox({
        title: title_,
        content: content_,
        color: "#296191",
        timeout: timeout,
        icon: "fa fa-bell swing animated"
    });
    
}

function activatesilders(ele) {
    if (ele == undefined) {
        $('.noUiSlider').each(function () {
            $(this).children().remove();
            $(this).parent().find(".nouislider-value").text(parseInt($(this).attr('currentstart')) + '-' + parseInt($(this).attr('currentend')));
            $(this).noUiSlider({

                range: [parseInt($(this).attr('start')), parseInt($(this).attr('end'))],
                start: [parseInt($(this).attr('currentstart')), parseInt($(this).attr('currentend'))],
                step: parseInt($(this).attr('step')),

                connect: true,
                slide: function () {
                    var values = $(this).val();
                    $(this).parent().find(".nouislider-value").text(parseInt(values[0]) + "-" + parseInt(values[1]));
                    $(this).attr('currentstart', parseInt(values[0]));
                    $(this).attr('currentend', parseInt(values[1]));
                }
            });
        });
    } else {
        ele.children().remove();
        ele.parent().find(".nouislider-value").text(parseInt(ele.attr('currentstart')) + '-' + parseInt(ele.attr('currentend')));
        ele.noUiSlider({


            range: [parseInt(ele.attr('start')), parseInt(ele.attr('end'))],
            start: [parseInt(ele.attr('currentstart')), parseInt(ele.attr('currentend'))],
            step: parseInt(ele.attr('step')),

            connect: true,
            slide: function () {
                var values = $(this).val();
                ele.parent().find(".nouislider-value").text(parseInt(values[0]) + "-" + parseInt(values[1]));
                ele.attr('currentstart', parseInt(values[0]));
                ele.attr('currentend', parseInt(values[1]));
            }
        });
    }
}

