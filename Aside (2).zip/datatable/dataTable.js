﻿function deleteAnything(table_, column_, value_,username) {
    if (table_ == 'Users') {
        table_ ='Link_User_Role'
    }
    $.ajax({
        type: 'GET',
        url: 'deleteanything?tablename=' + table_ + '&column=' + column_ + '&value=' + parseInt(value_),
        contentType: "application/json; charset=utf-8",
        dataType: "text",
        async: true,
        cache: false,
        success: function (data) {
            $.notify("Deleted", { className: 'success' });
            if (table_ == 'Link_User_Role') {
                table_ = 'Users';
                getBaseDetails();
                //tandava(username);
            }
            $('#' + table_ + 'Tab').DataTable().ajax.reload(null, false);
        },
        error: function (xhr, ajaxOptions, thrownError) {
        }
    });
}
function showAnything(Div_name, TableName, Columns, VisualCoulmns, metadata, conditions, needSearch) {
    var searchOption = true;
    if (needSearch != undefined) {
        searchOption = needSearch;
    }
    var VisualColumns_ = VisualCoulmns.split(',');
    var localCondition = '';
    if (conditions != undefined && conditions != null) { localCondition = ' ' + conditions };
    var columns_ = [];
    var Table = '<table id="' + TableName.replace(',','') + 'Tab" class="table table-striped table-bordered table-hover" width="100%"  identity="datatable" ><thead><tr>';
    for (var i = 0; i < VisualColumns_.length; i++) {
        var singleColumns = {};
        singleColumns.sName = VisualColumns_[i];
        var thSTyle = '';
        if (metadata != undefined && metadata[i].visible != undefined) {
            singleColumns.visible = metadata[i].visible;
            if (metadata[i].visible == false) {
                thSTyle = 'style="display:none"';
                //metadata.splice(i,1)
            }
        }
        columns_.push(singleColumns);
        Table = Table + '<th ' + thSTyle + '>' + VisualColumns_[i] + '</th>';
    }
    var newrenderMetadata = [];
    var backup_metadata = [];
    if (metadata != undefined) {
        for (var i = 0; i < metadata.length; i++) {
            if (metadata[i].visible == undefined || metadata[i].visible) {
                newrenderMetadata.push(metadata[i]);
            }
            backup_metadata.push(metadata[i]);
        }
        metadata = [];
        metadata = newrenderMetadata;
    }
    Table = Table + '<th style="width:10% !important; display:none" id="EditTH"><b>Edit/Delete</b></th></tr></thead></table>';
    $('#' + Div_name).append(Table);
    $('#' + TableName + 'Tab').dataTable({
        "bServerSide": false,
        "autoWidth": false, 
        "responsive": true,
        "pageLength": 10,
        "bLengthChange": false,
        "ajax": {
            "url": "getStadingdata?tablename=" + TableName + localCondition + "&columns=" + Columns,
            "type": "GET"
        },
        "bJQueryUI": false,
        "order": [],
        "searching": searchOption,
        "aoColumns": columns_,
        "createdRow": function (row, data, index) {
            $('#' + TableName + 'Tab').find('#EditTH').show();
            
            try {
                
                $($(row).find('td')[0]).click(function () {
                    if ($('#' + data[1] + '_Details').length == 0 && TableName=='Users') {
                        $('.details_').remove();
                        $(row).after('<tr class="details_" id="' + data[1] + '_Details"><td style="background-color:#ededed" colspan="' + $(row).find('td').length + '" class="details_" ><div class="col-md-6"><div class="panel-body" id="UserdetailsDiv" style="padding:0px"><div class="col-md-12"><h4 style="color: white;background-color: #00000073;padding: 5px;    margin-bottom: 8px"><i class="fa fa-fw   fa-share-alt"></i><b> Service Lines</b></h4></div></div></div><div class="col-md-6"><div class="panel-body" id="logpeers" style="padding:0px"><div class="col-md-12"><h4 style="color: white;background-color: #00000073;padding: 5px; margin-bottom: 8px"><i class="fa fa-fw   fa-envelope"></i><b>Notify</b></h4></div></div><div class="col-md-12"><textarea rows="8" style="resize:none;width:100%;    margin-bottom: 5px;" ></textarea></div><div class="col-md-6"></div><div class="col-md-6"><a href="javascript:de_mapserviceline()" class="btn btn-primary" style="width:100%">Notify User</a></div></div></td></tr>');

                        $('#UserdetailsDiv').append('<div class="col-md-6"><select multiple="" id="servicelines2" class="custom-scroll" style="height: 150px;width: 100%; margin-bottom: 5px;"></select><a href="javascript:de_mapserviceline()" class="btn btn-primary" style="width:100%">REMOVE Service line <i class="fa fa-fw   fa-angle-double-right"></i></a></div>');
                        $('#UserdetailsDiv').append('<div class="col-md-6"><select multiple="" id="servicelines3" class="custom-scroll" style="height: 150px;width: 100%; margin-bottom: 5px;"></select><a href="javascript:mapserviceline()" class="btn btn-primary" style="width:100%"><i class="fa fa-fw   fa-angle-double-left"></i> ADD Service line</a ></div>');
                        getselectedServiceline(data[1]);
                        
                    } else {
                        $('#' + data[1] + '_Details').remove();
                    }
                });

            } catch (e) { }

            var editcontrol = '<span class="edit_record" style="cursor: pointer" title="Edit" tablename="' + TableName + '"' +
                'column="' + Columns.split(',')[0] + '" value="' + data[0] + '">' +
                '<i class="fa fa-fw   fa-pencil"></i>' +
                '</span><span class="edit_control" style="display:none"><span class="save_record" style="cursor: pointer" title="Save" tablename="' + TableName + '"' +
                'column="' + Columns.split(',')[0] + '" value="' + data[0] + '">' +
                '<i class="fa fa-fw   fa-save"></i>' +
                '</span>' +
                '<span class="cancel_edit_record" style="cursor: pointer" title="Cancel edit" tablename="' + TableName + '"' +
                'column="' + Columns.split(',')[0] + '" value="' + data[0] + '">' +
                '<i class="fa fa-fw   fa-ban"></i>' +
                '</span></span>';

           //test
            editcontrol = '';

            if (metadata == undefined || metadata == null || metadata.length == 0) { editcontrol = ''; }
            else {
                var blankEdit = true;
                for (var i = 0; i < metadata.length; i++) {
                    if (metadata[i].editable) { blankEdit = false; break }
                }
                if (blankEdit) { editcontrol = ''; }
            }
            var deletecontrol = '<span class="delete_record" style="cursor: pointer" title="Delete" tablename="' + TableName + '"' +
                'column="' + Columns.split(',')[0] + '" value="' + data[0] + '">' +
                '<i class="fa fa-fw   fa-trash"></i>' +
                '</span></td>';
            
            if (data[1] == $('#user_').val() && TableName == 'Users') {
                //$($(row).find('td')[1]).html('');
                $($(row).find('td')[1]).append('<span class="label bg-color-blue txt-color-white pull-left" style="padding:4px;margin-right:5px">You </span>');
                //editcontrol = '';
                deletecontrol = '';
            }
            
            //$(row).append(
              //  '<td>' +
               // editcontrol + deletecontrol);

            $(row).find('.delete_record').click(function () {
                var tablename_ = $(this).attr('tablename');
                var column_ = $(this).attr('column');
                var value_ = $(this).attr('value');
                deleteAnything(tablename_, column_, value_);
            });
            $(row).find('.edit_record').click(function () {
                var cells_ = $(this).closest('tr').find('td');
                for (var i = 0; i < cells_.length - 1; i++) {
                    if (metadata[i].editable != undefined && metadata[i].editable) {
                        var Actualvalue = $(cells_[i]).html();
                        $(cells_[i]).html('');
                        var notnull = 'form-control editedVal';
                        if (metadata[i].nullable != undefined && !metadata[i].nullable) {
                            notnull = notnull + ' notnull';
                        }
                        if (metadata[i].controlType == undefined || metadata[i].controlType == 'input') {
                            $(cells_[i]).append(
                                '<input type="text" columnName="' + metadata[i].name + '" style="width:100%" class="' + notnull + '"' +
                                'ActualValue="' + Actualvalue + '"' +
                                'placeholder="' + Actualvalue + '"' +
                                'value="' + Actualvalue + '"' +
                                'data="' + Actualvalue + '"' +
                                'datatype="' + metadata[i].type + '"' +
                                '</input>');
                        } else if (metadata[i].controlType != undefined && metadata[i].controlType == 'select') {
                            var selectcontrol = '<select columnName="' + metadata[i].name + '" style="width:100%" class="input-sm editedVal"' +
                                'ActualValue="' + Actualvalue + '"' +
                                'placeholder="' + Actualvalue + '"' +
                                'value="' + Actualvalue + '"' +
                                'data="' + Actualvalue + '"' +
                                'datatype="' + metadata[i].type + '"' +
                                '>';
                            $.ajax({
                                type: 'GET',
                                url: metadata[i].controlurl,
                                contentType: "application/json; charset=utf-8",
                                async: false,
                                cache: false,
                                success: function (data) {
                                    for (var j = 0; j < data.length; j++) {
                                        selectcontrol = selectcontrol + '<option value="' + data[j] + '">' + data[j] + '</option>';
                                    }
                                    selectcontrol = selectcontrol + '</select>';
                                    $(cells_[i]).append(selectcontrol);
                                },
                                error: function (xhr, ajaxOptions, thrownError) {
                                }
                            });
                        }
                    }
                }
                $('.notnull').blur(function () { if ($(this).val() == '') { $(this).val($(this).attr('data')); } });
                $(this).hide();
                $(this).closest('td').find('.edit_control').show();
            });
            $(row).find('.cancel_edit_record').click(function () {
                var cells_ = $(this).closest('tr').find('td');
                for (var i = 0; i < cells_.length - 1; i++) {
                    var val = $(cells_[i]).find('.editedVal').attr('data');
                    $(cells_[i]).html(val);
                }
                $(this).parent().hide();
                $(this).closest('td').find('.edit_record').show();
            });
            $(row).find('.save_record').click(function () {
                var cells_ = $(this).closest('tr').find('td');
                var updater = {};
                updater.tablename = $(this).attr('tablename');
                updater.setcommand = '';
                updater.where = $(this).attr('column') + '="' + $(this).attr('value') + '"';
                for (var i = 0; i < cells_.length - 1; i++) {
                    if ($(cells_[i]).find('.editedVal').attr('columnname') != undefined &&
                        $(cells_[i]).find('.editedVal').attr('columnname') != ''
                    ) {
                        var val = $(cells_[i]).find('.editedVal').val();
                        var columnName = $(cells_[i]).find('.editedVal').attr('columnname');
                        var sqlVal = '';
                        if ($(cells_[i]).find('.editedVal').attr('datatype') == 'string') {
                            sqlVal = columnName + '="' + val + '"';
                        } else {
                            sqlVal = columnName + '=' + val;
                        }
                        if (updater.setcommand == '') {
                            updater.setcommand = sqlVal;
                        } else {
                            updater.setcommand = updater.setcommand + ',' + sqlVal;
                        }
                    }
                }
                var my = $(this);
                $.ajax({
                    type: 'POST',
                    url: restServiceConfig.protocol + '://' + restServiceConfig.host + ':' + restServiceConfig.port + '/Opsole/service/policy/updateanything',
                    contentType: "application/json; charset=utf-8",
                    dataType: "text",
                    data: JSON.stringify(updater),
                    async: true,
                    cache: false,
                    success: function (data) {
                        $.notify('Updated', { className: 'success' });
                        for (var i = 0; i < cells_.length - 1; i++) {
                            var val = $(cells_[i]).find('.editedVal').val();
                            $(cells_[i]).html(val);
                        }
                        my.parent().hide();
                        my.closest('td').find('.edit_record').show();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                    }
                });
            });

        },
        "initComplete": function (settings, json) {
            if (TableName == 'Users') {
                $($('#UsersTab_wrapper .col-sm-6')[0]).append(
                    '<input type="text" class="input-sm" id="newuser" readonly="readonly" placeholder="Username">' +
                    '<label style="margin-left:10px;padding-right: 5px"> Role</label><select class="input-sm" id="newuserrole">' +
                    '<option value="3">User</option><option value="2">Manager</option></select>' +
                    '<a id="adduser" style="margin-left:10px" href="javascript:CreateUser();" class="btn btn-primary">' +
                    'Add User</a><a id= style="margin-left:10px" onclick="$(\'#UsersTab\').DataTable().ajax.reload(null, false);" class="btn btn-primary"><i class="fa fa-fw fa-retweet"></i>Refresh</a>');
                    setInterval(function () { if ($('.details_').length == 0) { $('#' + TableName + 'Tab').DataTable().ajax.reload(null, false) } }, 10000);

            }
        },
        "drawCallback": function (oSettings) {

        },

    });
}
function getAnswers(ConvID,_id) {
    $.ajax({
        type: 'GET',
        url: "getchatdata?ConvID=" + ConvID+'&target='+$('#allproject').val(),
        contentType: "application/json; charset=utf-8",
        async: true,
        cache: false,
        success: function (data) {
            if (data != "") {
                $('#' + _id + ' div').append(data);
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
        }
    });
}
function DataTableSearchPatch(tableName) {
    $('input[aria-controls="' + tableName + '"]').unbind().keyup(function (event) {
        var value = $(this).val();
        if (value.length >= 3 && event.which == 13) {
            $('#' + tableName).DataTable().search(value).draw();
        } else if (value.length ==0) { $('#' + tableName).DataTable().search('').draw(); }
    });
}
function getspamham(row, data) {
    $.ajax({
        url: '../Home/getstatus?k=' + data + '&target=spamham',
        type: "GET",
        cache: false,
        dataType: 'json',
        async: true,
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            Extracontrol = likeDislike.replace('{id}', data);
            Extracontrol = Extracontrol.replace('{id}', data);

            if (result == '') {

                row.append('<td style="vertical-align: inherit;">' + Extracontrol + '</td>');
            }
            else {
                var control = $('<td style="vertical-align: inherit;">' + Extracontrol + '</td>');
                if (result == 'ham') {
                    control.find('.like').attr('style', 'color:white;background-color:#0a71af');
                    control.find('.like').attr('onclick', '');
                } else if (result == 'spam') {
                    control.find('.dislike').attr('style', 'color:white;background-color:#af531b');
                    control.find('.dislike').attr('onclick', '');
                }
                row.append(control);
            }

        },
        error: function (err) {
            alert(err.statusText);
        }
    });
}
function showAnything_mongoVer(Div_name, TableName, Columns, VisualCoulmns, metadata, conditions, needSearch,link) {
    var searchOption = true;
    if (needSearch != undefined) {
        searchOption = needSearch;
    }
    var VisualColumns_ = Columns.split(',');
    var localCondition = '';
    if (conditions != undefined && conditions != null) { localCondition = ' ' + conditions };
    var columns_ = [];
    var Table = '<table id="' + TableName.replace(',', '') + 'Tab" class="table table-striped table-bordered table-hover" width="100%"  identity="datatable" ><thead><tr>';
    for (var i = 0; i < VisualColumns_.length; i++) {
        var singleColumns = {};
        singleColumns.sName = VisualColumns_[i];
        var thSTyle = '';
        if (metadata != undefined && metadata[i].visible != undefined) {
            singleColumns.visible = metadata[i].visible;
            if (metadata[i].visible == false) {
                thSTyle = 'style="display:none"';
            }
        }
        columns_.push(singleColumns);
        Table = Table + '<th ' + thSTyle + '>' + VisualCoulmns.split(',')[i] + '</th>';
        
    }
    if (TableName == 'clusterTableanalytics') {
        Table = Table + '<th style="width:10% !important; display:none" id="EditTH"><b>Action</b></th></tr></thead></table>';
    } else {
        Table = Table + '</tr></thead></table>';
    }
    var newrenderMetadata = [];
    var backup_metadata = [];
    if (metadata != undefined) {
        for (var i = 0; i < metadata.length; i++) {
            if (metadata[i].visible == undefined || metadata[i].visible) {
                newrenderMetadata.push(metadata[i]);
            }
            backup_metadata.push(metadata[i]);
        }
        metadata = [];
        metadata = newrenderMetadata;
    }
   // Table = Table + '<th style="width:10% !important; display:none" id="EditTH"><b>Action</b></th></tr></thead></table>';
    Table = Table + '</tr></thead></table>';
    $('#' + Div_name).append(Table);
    $('#' + TableName + 'Tab').dataTable({
        "bServerSide": true,
        "autoWidth": false,
        "responsive": true,
        "pageLength": 10,
        "bLengthChange": false,
        "ajax": {
            "url": link ,
            "type": "POST"
        },
        "bJQueryUI": false,
        "order": [],
        "searching": searchOption,
        "aoColumns": columns_,
        "createdRow": function (row, data, index) {
            $('#' + TableName + 'Tab').find('#EditTH').show();
            if (TableName == 'mailbox') {
                try {
                    $($(row).find('td')[0]).attr('style', 'cursor: pointer;');
                    //$($(row).find('td')[0]).append('<span class="label bg-color-blue txt-color-white pull-right" style="font-size:13px" id="currentBOT">' + data[3] + '</span>');
                    $($(row).find('td')[0]).click(function () {
                        if ($('#' + data[0] + '_Details').length == 0 ) {
                            $('.details_').remove();

                            var toaddress = '<div class="col-md-12" style="padding:0px">' +
                                '<div onclick="$(this).find(\'input\').focus()" class="bootstrap-tagsinput tagdestination syn" id="toadd_'+data[0]+'">' +
                                '<input type="text" style="width:100%;padding-left:5px" class="tagsource input-sm" placeholder="To">' +
                                '</div></div>';

                            $(row).after('<tr class="details_tr" id="' + data[0] + '_Details"><td style="padding:0px" colspan="' + $(row).find('td').length + '" class="details_" >' +
                                '<div id="body_' + data[0] +'" class="col-md-12" style="background-color:white;padding: 10px;"></div>'+
                                '<div class="col-md-6" style="margin-top:20px;margin-bottom:10px;">' +
                                toaddress +
                                '<div class="col-md-12" style="padding:0px;margin-top:10px">'+
                                    '<div class="col-md-12 mail_box" style="margin-top:8px;padding:10px"></div>' +
                                    '<div class="col-md-12 action" style="margin-top:8px;padding: 5px;background-color:#afadad7a"><a class="btn btn-primary btn-sm pull-right" id="sendmail"><i class="fa fa-send"></i> Send Mail</a></div>' +
                                '</div>' +
                                '</div>'+
                                '<div class="col-md-6 solutions_" style="margin-top:20px;max-height:400px;overflow:auto;margin-bottom:10px;"><div class="panel-group smart-accordion-default" id="data_' + data[0] +'"></div></div>'+
                                '</td></tr>');

                            $('#' + TableName + 'Tab').find('.details_ .mail_box').summernote({
                                height: 300,
                                hint: {
                                    words: ['apple', 'orange', 'watermelon', 'lemon'],
                                    match: /\b(\w{1,})$/,
                                    search: function (keyword, callback) {
                                        callback($.grep(this.words, function (item) {
                                            return item.indexOf(keyword) === 0;
                                        }));
                                    }
                                },
                                codemirror: { 
                                    theme: 'monokai'
                                }
                            });
                            $('#' + TableName + 'Tab').find('.note-insert').remove();
                            $('#' + TableName + 'Tab').find('.note-statusbar').remove();
                            
                            $('#' + TableName + 'Tab').find('.note-editable').attr('id','manimail_'+data[0]);
                            evaluate_param();
                            get_solution_mails(data[0], $('.solutions_'),data[2]);

                        } else {
                            $('#' + data[0] + '_Details').remove();
                            $('#' + TableName + 'Tab').find('.details_ .col-md-12').summernote('destroy');
                        }
                        $('#sendmail').click(function () {
                            basicalert('Mail', 'Sending......', 4000);
                            var data_ = {};
                            var mail_ = {};
                            mail_.to = [];
                            $('#toadd_' + data[0]).find('.tag').each(function () { mail_.to.push($(this).text());});
                            mail_.form = "";
                            mail_.subject = data[2];
                            mail_.body = $('#manimail_' + data[0]).html();
                            data_.details = mail_;
                            sendmail(data_);
                        });
                    });

                } catch (e) { }
            }

            if (TableName == 'training_log' || TableName == 'cleaning_log') {
               //$($(row).find('td')[0]).html('test');
                $($(row).find('td')[1]).append('%');

                var starttime =Number($($(row).find('td')[2]).html());
                $($(row).find('td')[2]).html(new Date(starttime).toDateString() + ' ' + new Date(starttime).toTimeString().split(' ')[0]);

                starttime = Number($($(row).find('td')[3]).html());
                $($(row).find('td')[3]).html(new Date(starttime).toDateString() + ' ' + new Date(starttime).toTimeString().split(' ')[0]);
           }

            var Extracontrol = '';
            if (TableName == 'clusterTableanalytics') {
                getspamham($(row), data[0]);
            }
            

            //$(row).find('.delete_record').click(function () {
            //    var tablename_ = $(this).attr('tablename');
            //    var column_ = $(this).attr('column');
            //    var value_ = $(this).attr('value');
            //    deleteAnything(tablename_, column_, value_);
            //});

        },
        "initComplete": function (settings, json) {
            
            DataTableSearchPatch(TableName + 'Tab');
            $('#' + TableName + 'Tab_info').attr('class', 'dataTables_info pull-left');
            $('#' + TableName + 'Tab_info').attr('style', 'padding-left:5px');
            if (TableName == 'clusterTable') {
                $($('#' + TableName + 'Tab_wrapper .row')[1]).find('.col-sm-12').attr('style', 'overflow:auto;max-height:400px');
            } else if (TableName == 'clusterTableanalytics') {
                var cleandata = '<div class="col-md-7"><div class="col-md-6" style="text-align: center !important;"><button type="button" class="btn btn-success cleandata" onclick="cleandata()"><i class="fas fa-snowplow"></i> Clean Data</button></div>';
                var traindata = '<div class="col-md-6" style="text-align: center !important;"><button type="button" class="btn btn-success traindata" onclick="traindata()"><i class="fas fa-brain"></i> Train Data</button></div></div>';
                $($($('#' + TableName + 'Tab_wrapper .row')[0]).find('.col-md-6')[0]).append('<div class="row"><div class="col-md-5"><select class="form-control" style="width:100%" id="modulelist"><option value="All">All</option></select></div>' + cleandata + traindata + '</div>');
                $.ajax({
                    url: '../Home/getlist_distinct?k=Module&target=6611_dump',
                    type: "GET",
                    cache: false,
                    dataType: 'json',
                    async: true,
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        for (var i = 0; i < data.length; i++) {
                            $('#modulelist').append('<option value="' + data[i] + '">' + data[i] + '</option>');
                        }
                        $('#modulelist').change(function () {
                            if ($('#modulelist').val() != 'All') {
                                $('#' + TableName + 'Tab').DataTable().ajax.url('../Datatable/getdatatabledata?target=6611_dump&columns__=Module,Solution,Ticket Solution&link=' + $('#modulelist').val());
                                $('#' + TableName + 'Tab').DataTable().ajax.reload(null, true);
                            } else {
                                $('#' + TableName + 'Tab').DataTable().ajax.url('../Datatable/getdatatabledata?target=6611_dump&columns__=Module,Solution,Ticket Solution');
                                $('#' + TableName + 'Tab').DataTable().ajax.reload(null, true);
                            }
                        });
                    },
                    error: function (err) {
                        alert("Error")
                    }
                });
                getcleantrainstatus();
                setInterval(function () { getcleantrainstatus(); }, 5000);
            } 
            if (TableName == 'mailbox') {
                setInterval(function () { if ($('#' + TableName + 'Tab').find('.details_').length == 0) { $('#' + TableName + 'Tab').DataTable().ajax.reload(null, false) } }, 5000);
            }
           // $('#' + TableName + 'Tab thead').attr('style', 'background-color: #f7755f;color: white;');
            //$('#' + TableName + 'Tab').attr('style', 'border-bottom: solid 10px #f7745f9e;border-left: solid 1px #f7745f;border-right: solid 1px #f7745f;');
            //setInterval(function () { if ($('.details_').length == 0) { $('#' + TableName + 'Tab').DataTable().ajax.reload(null, false) } }, 10000);
        },
        "drawCallback": function (oSettings) {

        },

    });
}

function evaluate_param() {
    $('.tagsource').keypress(function (e) {
        if (e.key == "Enter") {
            var alreadyExist = false;
            for (var i = 0; i < $(this).parent().parent().parent().parent().find('.tag').length; i++) {
                if ($($(this).parent().parent().parent().parent().find('.tag')[i]).text().toUpperCase() == $(this).val().toUpperCase()) {
                    $($(this).parent().parent().parent().parent().find('.tag')[i]).notify("Already Exists", { className: 'success', position: "top center" });
                    alreadyExist = true; break;
                }
            }

            if ($(this).val() != '' && !alreadyExist) {
                for (var oneword = 0; oneword < $(this).val().split(',').length; oneword++) {
                    if ($(this).parent().parent().parent().find('.synsource').val() == '') { $(this).parent().parent().parent().find('.synsource').val($(this).val().split(',')[oneword]); }
                    $(this).parent().parent().find('.tagdestination').find('.tagsource').before('<span class="tag label label-info">' + $(this).val().split(',')[oneword] + '<span data-role="remove" onclick="$(this).parent().remove()"></span></span>');
                }
                $(this).val('');
            }
        }
    });
}
function get_solution_mails(objectid,ele,subject) {
    $.ajax({
        url: "../outlook/getsolution?objectid=" + objectid,
        type: "get",
        cache: false,
        dataType: 'json',
        async: true,
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            $('#body_' + objectid).html('<b>Description</b><br>' + data.body + '<br><a class="btn btn-danger btn-sm escalate" style="margin-top: 10px;"><i class="fa fa-upload"></i> Escalate</a>');
            $('#body_' + objectid).find('.escalate').click(function () {
                basicalert('Mail', 'That ESCALATED quickly', 4000);
                var data_ = {};
                var mail_ = {};
                mail_.to = [];
                mail_.form = "";
                mail_.subject = subject;
                mail_.body = data.body;
                data_.details = mail_;
                sendmail(data_);
            });
            $('#toadd_' + objectid).find('input').before('<span class="tag label label-info">' + data.from+'</span>');
            for (var i = 0; i < data.solutions.length; i++) {
                ele.find('#data_' + objectid).append('<div class="panel panel-default">' +
                    '<div class="panel-heading">' +
                    '<h4 class="panel-title">' +
                    '<a data-toggle="collapse" data-parent="#data_' + objectid+'" href="#collapse-'+i+'" class="collapsed">' +
                    '<i class="fa fa-fw fa-plus-circle txt-color-green"></i> ' +
                    '<i class="fa fa-fw fa-minus-circle txt-color-red"></i> Solution #'+(i+1)+' </a></h4>' +
                    '</div>' +
                    '<div id="collapse-'+i+'" class="panel-collapse collapse">' +
                    '<div class="panel-body" style="cursor: pointer">' +
                    data.solutions[i] +
                    '</div>' +
                    '</div>' +
                    '</div>');
            }
            ele.find('#data_' + objectid).find('.panel-body').click(function () {
                $('#manimail_' + objectid).html('<p>Dear User,</p>' + $(this).html() + '<br><br><p>Thanks</p><p><span style="font-weight: bold;">iBots System</span><br><br></p>');
            });
            $(ele.find('#data_' + objectid).find('.panel-body')[0]).click();
        },
        error: function (err) {
            alert("Error")
        }
    });
}
