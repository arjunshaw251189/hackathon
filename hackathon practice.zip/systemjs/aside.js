var pagename= $(location). attr("href").split('/')[ $(location). attr("href").split('/').length-1].split('?')[0].split('.')[0];
document.write('<link rel="stylesheet" href="../css/menu_styles.css">');
document.write('<link rel="stylesheet" href="../css/all.css">');
///BOOTSTRAP//////////////////////////////////////////////////////////////////////////////
document.write('<link href="../lib/BootStrap/bootstrap.min.css" rel="stylesheet"></link>');
document.write('<script src="../lib/BootStrap/bootstrap.min.js"></script>');
///////////////////////////////////////////////////////////////////////////////////////////
///DATATABLE//////////////////////////////////////////////////////////////////////////////
document.write('<link href="../lib/datatable/datatable.css" rel="stylesheet"></link>');
document.write('<script src="../lib/datatable/jquery.dataTables.min.js"></script>');
///////////////////////////////////////////////////////////////////////////////////////////
////PAGE JS////////////////////////////////////////////////////////////////////////////////
document.write('<script src="../pagejs/'+pagename+'.js"></script>');
///////////////////////////////////////////////////////////////////////////////////////////
$(document).ready(function(){
	$('.menu').append('<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>');
	$('.menu').append('<div id="menu" class="sidenav"></div>');
	$('#menu').append('<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>');
	$('#menu').append('<a href="../html/mails.html">Inbox</a>');
});

function openNav() {
  $('#menu')[0].style.width = "30%";
}

function closeNav() {
  $('#menu')[0].style.width = "0%";
}

function createdatatable_ver1(tablename)
{
$('#'+tablename)
				.addClass( 'display nowrap dataTable dtr-inline collapsed' )
				.dataTable( {
					responsive: true,
					bLengthChange:false,
					"initComplete": function (settings, json) {
						$('#'+tablename+'_filter').find('input[type="search"]').addClass('form-control');
						
					}
				} );	
}