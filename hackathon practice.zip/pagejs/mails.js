$(document).ready( function () {
	createdatatable_ver1('mailbox_tab');
} );